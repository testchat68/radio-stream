#!/bin/bash
set -e

echo "=== Създаване на .deb пакет за Radio Player ==="

if ! command -v valac >/dev/null 2>&1; then
    echo "Инсталиране на необходимите пакети..."
    sudo apt update
    sudo apt install -y valac libgtk-3-dev libgstreamer1.0-dev \
        gstreamer1.0-plugins-base gstreamer1.0-plugins-good \
        gstreamer1.0-plugins-bad gstreamer1.0-libav imagemagick
fi

if ! command -v valac >/dev/null 2>&1; then
    echo "Грешка: valac не може да бъде инсталиран."
    exit 1
fi

mkdir -p radio-player-deb/usr/bin
mkdir -p radio-player-deb/usr/share/applications
mkdir -p radio-player-deb/usr/share/icons/hicolor/128x128/apps
mkdir -p radio-player-deb/DEBIAN

echo "Компилиране на radio-player..."
valac --pkg gtk+-3.0 --pkg gstreamer-1.0 -X -lm radio-player.vala \
    -o radio-player-deb/usr/bin/radio-player

chmod 755 radio-player-deb/usr/bin/radio-player

cat > radio-player-deb/usr/share/applications/radio-player.desktop << 'EOF'
[Desktop Entry]
Name=Internet Player
Comment=Simple internet stream player
Exec=radio-player
Icon=radio-player
Terminal=false
Type=Application
Categories=AudioVideo;Audio;
Keywords=radio;stream;music;internet;
StartupNotify=true
EOF
chmod 644 radio-player-deb/usr/share/applications/radio-player.desktop

if [ -f icons/radio-player.png ]; then
    cp icons/radio-player.png radio-player-deb/usr/share/icons/hicolor/128x128/apps/radio-player.png
    echo "Иконата е копирана."
else
    echo "Внимание: icons/radio-player.png не е намерен."
fi

SIZE=$(du -sk radio-player-deb/usr 2>/dev/null | cut -f1 || echo "300")
cat > radio-player-deb/DEBIAN/control << EOF
Package: radio-player
Version: 1.0.1
Section: sound
Priority: optional
Architecture: amd64
Installed-Size: $SIZE
Depends: libgtk-3-0, gstreamer1.0-plugins-base, gstreamer1.0-plugins-good, gstreamer1.0-plugins-bad, gstreamer1.0-libav, gstreamer1.0-pulseaudio
Maintainer: Internet Player <radio@example.com>
Description: Simple internet stream player
 A clean GTK3 stream player written in Vala.
 Supports multiple internet radio/stream stations with play/pause, stop, volume, preamp and per-station EQ.
EOF

echo "Изграждане на .deb пакета..."
dpkg-deb --root-owner-group --build radio-player-deb radio-player_1.0.1_amd64.deb

echo ""
echo "========================================"
echo "Готово! Пакетът е създаден:"
echo "  radio-player_1.0.1_amd64.deb"
echo ""
echo "Инсталация:"
echo "  sudo dpkg -i radio-player_1.0.1_amd64.deb"
echo "  sudo apt install -f"
echo "========================================"
