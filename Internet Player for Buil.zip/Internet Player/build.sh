#!/bin/bash
# Компилиране на Radio Player за Linux Mint 22.2

set -e

echo "Инсталиране на необходимите пакети..."
sudo apt update
sudo apt install -y valac libgtk-3-dev libgstreamer1.0-dev gstreamer1.0-plugins-base gstreamer1.0-plugins-good gstreamer1.0-plugins-bad gstreamer1.0-libav

echo "Компилиране..."
valac --pkg gtk+-3.0 --pkg gstreamer-1.0 radio-player.vala -o radio-player

echo "Готово! Стартирай с:"
echo "./radio-player"
