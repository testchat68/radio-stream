using Gtk;
using Gst;

public class RadioPlayer : Gtk.Application {
    private Gtk.Window window;
    private Gtk.ComboBoxText station_combo;
    private Gtk.Button pause_button;
    private Gtk.Button stop_button;
    private Gtk.Scale volume_scale;
    private Gtk.Scale preamp_scale;
    private Gtk.Label status_label;
    private Gtk.Label status_dot;
    private Gtk.Label eq_led;
    private Gtk.Label eq_text;
    private Gst.Element playbin;
    private Gst.Element equalizer;
    private Gst.Element preamp;
    private Gst.Bin audio_bin;
    private bool is_playing = false;
    private int current_station = 0;
    private bool eq_enabled = true;
    private const int EQ_BANDS = 10;
    private Gtk.Scale[] eq_scales = new Gtk.Scale[EQ_BANDS];
    private Gtk.Label[] eq_value_labels = new Gtk.Label[EQ_BANDS];
    private double*[] station_eq;
    private ulong[] eq_handler_ids = new ulong[EQ_BANDS];
    private int[] eq_freqs = { 29, 59, 119, 237, 474, 947, 1889, 3770, 7523, 15011 };
    private double[] default_eq = { 6.0, 3.0, -2.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 3.0 };

    private string[] station_names = {
        "F1: Maretimo Lounge",
        "F2: NRJ Energy",
        "F3: Вега+ Сандански",
        "F4: Rádio Scalla",
        "F6: Radio Lola",
        "F7: Radio Naxi Boem",
        "Naxi Cafe",
        "Naxi 70-e",
        "Naxi 80-e",
        "Naxi Gold",
        "F8: Radio Ваня",
        "Naxi Šlager",
        "Naxi Evergreen",
        "Радио 1",
        "Radio Focus",
        "Радио Витоша"
    };

    private string[] station_urls = {
        "https://s35.derstream.net/lounge.mp3",
        "http://play.global.audio/nrj128",
        "http://88.80.96.25:8040/;",
        "https://s01.svrdedicado.org:6782/stream",
        "https://streaming.tdiradio.com/radiolola.mp3",
        "http://naxidigital-boem128.streaming.rs:8160",
        "https://naxidigital-cafe128ssl.streaming.rs:8022/;stream.nsv",
        "https://naxidigital-70s128ssl.streaming.rs:8382/;stream.nsv",
        "https://naxidigital-80s128ssl.streaming.rs:8042/;stream.nsv",
        "https://naxidigital-gold128ssl.streaming.rs:8062/;stream.nsv",
        "https://icecast-radiovanya.cdnvideo.ru/radiovanya",
        "https://naxidigital-slager128ssl.streaming.rs:8372/;stream.nsv",
        "https://naxidigital-evergreen128ssl.streaming.rs:8012/;stream.nsv",
        "https://playerservices.streamtheworld.com/api/livestream-redirect/RADIO_1AAC_H.aac",
        "http://213.91.195.242:2524/stream",
        "https://bss1.neterra.tv/vitosha/vitosha.m3u8"
    };

    private string config_file;
    private string eq_dir;
    private Gtk.Button eq_toggle_btn;
    private Gtk.Button save_btn;

    public RadioPlayer() {
        GLib.Object(application_id: "com.example.radioplayer", flags: ApplicationFlags.FLAGS_NONE);
    }

    protected override void activate() {
        string[] gst_args = {};
        unowned string[] gst_args_unowned = gst_args;
        Gst.init(ref gst_args_unowned);

        window = new Gtk.Window() {
            title = "Internet Player",
            default_width = 420,
            default_height = 480,
            resizable = false
        };
        window.set_application(this);
        window.destroy.connect(quit);

        var css_provider = new Gtk.CssProvider();
        try {
            css_provider.load_from_data("""
                window { background-color: #1a0a2e; }
                label { color: #e0e0e0; }
                .station-title { color: #7eb8ff; font-size: 18px; font-weight: bold; }
                .section-title { color: #7eb8ff; font-size: 16px; font-weight: bold; }
                .status-playing { color: #facc15; font-weight: bold; font-size: 13px; }
                .led-green-on { color: #7fff00; font-size: 18px; text-shadow: 0 0 6px #7fff00; }
                .led-green-off { color: #183D22; font-size: 18px; }
                .led-red-on { color: #FF0000; font-size: 18px; text-shadow: 0 0 6px #FF0000; }
                .led-red-off { color: #481818; font-size: 18px; }
                .eq-text { color: #ff6d00; font-size: 13px; font-weight: bold; }
                button {
                    background-color: #2a1a4a; border: 1px solid #4a3a6a; border-radius: 6px;
                    min-height: 36px; min-width: 90px; color: white; font-size: 14px;
                }
                button.add-btn { min-width: 36px; min-height: 36px; font-size: 18px; font-weight: bold; padding: 0; }
                button.eq-btn { min-width: 70px; min-height: 28px; font-size: 12px; padding: 2px 6px; }
                button:hover { background-color: #3a2a5a; }
                scale trough { min-height: 6px; border-radius: 3px; background-color: #3a2a5a; }
                scale highlight { background-color: #3b82f6; border-radius: 3px; }
                scale slider { min-width: 14px; min-height: 14px; border-radius: 7px; background-color: white; }
                combobox {
                    background: #2a1a4a; border: 1px solid #4a3a6a; border-radius: 4px;
                    color: white; font-weight: bold; font-size: 14px;
                }
                combobox button { background: transparent; border: none; min-height: 0; min-width: 0; color: white; }
            """);
        } catch (Error e) {}

        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), css_provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        );

        var main_box = new Gtk.Box(Gtk.Orientation.VERTICAL, 6) {
            margin_start = 12, margin_end = 12, margin_top = 8, margin_bottom = 8
        };

        config_file = Path.build_filename(Environment.get_user_config_dir(), "internet-player", "stations.conf");
        eq_dir = Path.build_filename(Environment.get_user_config_dir(), "internet-player", "eq");
        DirUtils.create_with_parents(eq_dir, 0755);
        load_custom_stations();
        init_eq_memory();

        var station_title = new Gtk.Label("Station:") { halign = Gtk.Align.CENTER };
        station_title.get_style_context().add_class("station-title");

        var station_row = new Gtk.Box(Gtk.Orientation.HORIZONTAL, 6) {
            halign = Gtk.Align.CENTER, hexpand = true
        };
        station_combo = new Gtk.ComboBoxText() { hexpand = true };
        refresh_station_combo();
        station_combo.changed.connect(on_station_changed);

        var add_button = new Gtk.Button.with_label("+") { tooltip_text = "Add station" };
        add_button.get_style_context().add_class("add-btn");
        add_button.clicked.connect(on_add_station);

        var remove_button = new Gtk.Button.with_label("−") { tooltip_text = "Remove selected station" };
        remove_button.get_style_context().add_class("add-btn");
        remove_button.clicked.connect(on_remove_station);

        station_row.pack_start(station_combo, true, true, 0);
        station_row.pack_start(add_button, false, false, 0);
        station_row.pack_start(remove_button, false, false, 0);

        var button_box = new Gtk.Box(Gtk.Orientation.HORIZONTAL, 12) {
            halign = Gtk.Align.CENTER, margin_top = 2
        };
        pause_button = new Gtk.Button.with_label("▶  Play") { tooltip_text = "Play / Pause" };
        pause_button.clicked.connect(on_pause_clicked);
        stop_button = new Gtk.Button.with_label("■  Stop") { tooltip_text = "Stop" };
        stop_button.clicked.connect(on_stop_clicked);
        button_box.pack_start(pause_button, false, false, 0);
        button_box.pack_start(stop_button, false, false, 0);

        var volume_label = new Gtk.Label("Volume") { halign = Gtk.Align.CENTER, margin_top = 2 };
        volume_label.get_style_context().add_class("section-title");
        volume_scale = new Gtk.Scale.with_range(Gtk.Orientation.HORIZONTAL, 0.0, 1.0, 0.01) {
            draw_value = false, hexpand = true
        };
        volume_scale.set_value(0.7);
        volume_scale.value_changed.connect(on_volume_changed);

        var preamp_label = new Gtk.Label("Preamp") { halign = Gtk.Align.CENTER, margin_top = 2 };
        preamp_label.get_style_context().add_class("section-title");
        preamp_scale = new Gtk.Scale.with_range(Gtk.Orientation.HORIZONTAL, -12.0, 12.0, 0.5) {
            draw_value = true, hexpand = true, value_pos = Gtk.PositionType.RIGHT,
            has_origin = true
        };
        preamp_scale.set_value(-2.0);
        preamp_scale.add_mark(0.0, Gtk.PositionType.BOTTOM, "0");
        preamp_scale.value_changed.connect(on_preamp_changed);

        var eq_btn_box = new Gtk.Box(Gtk.Orientation.HORIZONTAL, 8) {
            halign = Gtk.Align.CENTER, margin_top = 2
        };
        eq_toggle_btn = new Gtk.Button.with_label("EQ ON") { tooltip_text = "Toggle equalizer" };
        eq_toggle_btn.get_style_context().add_class("eq-btn");
        eq_toggle_btn.clicked.connect(on_eq_toggle);

        var reset_btn = new Gtk.Button.with_label("RESET") { tooltip_text = "Reset EQ for current station" };
        reset_btn.get_style_context().add_class("eq-btn");
        reset_btn.clicked.connect(on_eq_reset);

        save_btn = new Gtk.Button.with_label("SAVE") { tooltip_text = "Save EQ for current station" };
        save_btn.get_style_context().add_class("eq-btn");
        save_btn.clicked.connect(on_eq_save);

        eq_btn_box.pack_start(eq_toggle_btn, false, false, 0);
        eq_btn_box.pack_start(reset_btn, false, false, 0);
        eq_btn_box.pack_start(save_btn, false, false, 0);

        var eq_label = new Gtk.Label("Equalizer") { halign = Gtk.Align.CENTER, margin_top = 2 };
        eq_label.get_style_context().add_class("section-title");

        var eq_box = new Gtk.Box(Gtk.Orientation.HORIZONTAL, 2) {
            halign = Gtk.Align.CENTER, margin_top = 2
        };
        for (int i = 0; i < EQ_BANDS; i++) {
            var band_box = new Gtk.Box(Gtk.Orientation.VERTICAL, 1) { halign = Gtk.Align.CENTER };
            string label_text;
            if (eq_freqs[i] >= 1000)
                label_text = "%.0fk".printf(eq_freqs[i] / 1000.0);
            else
                label_text = "%d".printf(eq_freqs[i]);
            var freq_label = new Gtk.Label(label_text) { halign = Gtk.Align.CENTER };
            freq_label.set_tooltip_text("%d Hz".printf(eq_freqs[i]));
            eq_scales[i] = new Gtk.Scale.with_range(Gtk.Orientation.VERTICAL, -12.0, 12.0, 0.5) {
                inverted = true, draw_value = false, height_request = 70, width_request = 28
            };
            eq_scales[i].set_value(0.0);
            eq_handler_ids[i] = eq_scales[i].value_changed.connect(on_eq_changed);
            eq_value_labels[i] = new Gtk.Label("0") { halign = Gtk.Align.CENTER };
            eq_value_labels[i].set_width_chars(3);
            band_box.pack_start(freq_label, false, false, 0);
            band_box.pack_start(eq_scales[i], true, true, 0);
            band_box.pack_start(eq_value_labels[i], false, false, 0);
            eq_box.pack_start(band_box, false, false, 0);
        }

        var status_box = new Gtk.Box(Gtk.Orientation.HORIZONTAL, 6) {
            halign = Gtk.Align.CENTER, margin_top = 4
        };
        eq_text = new Gtk.Label("EQ") { halign = Gtk.Align.CENTER };
        eq_text.get_style_context().add_class("eq-text");
        eq_led = new Gtk.Label("●") { halign = Gtk.Align.CENTER };
        eq_led.get_style_context().add_class("led-red-on");
        status_dot = new Gtk.Label("●") { halign = Gtk.Align.CENTER };
        status_dot.get_style_context().add_class("led-green-off");
        status_label = new Gtk.Label("Stopped") { halign = Gtk.Align.CENTER };
        status_label.get_style_context().add_class("status-playing");
        status_box.pack_start(eq_text, false, false, 0);
        status_box.pack_start(eq_led, false, false, 0);
        status_box.pack_start(status_dot, false, false, 0);
        status_box.pack_start(status_label, false, false, 0);

        main_box.pack_start(station_title, false, false, 0);
        main_box.pack_start(station_row, false, false, 0);
        main_box.pack_start(button_box, false, false, 0);
        main_box.pack_start(volume_label, false, false, 0);
        main_box.pack_start(volume_scale, false, false, 0);
        main_box.pack_start(preamp_label, false, false, 0);
        main_box.pack_start(preamp_scale, false, false, 0);
        main_box.pack_start(eq_btn_box, false, false, 0);
        main_box.pack_start(eq_label, false, false, 0);
        main_box.pack_start(eq_box, false, false, 0);
        main_box.pack_start(status_box, false, false, 0);

        window.add(main_box);
        window.show_all();

        setup_player();
        apply_station_eq_to_ui(0);
        update_eq_led();
        update_play_led(false);
    }

    private void init_eq_memory() {
        station_eq = new double*[station_urls.length];
        for (int s = 0; s < station_urls.length; s++) {
            station_eq[s] = new double[EQ_BANDS];
            for (int b = 0; b < EQ_BANDS; b++)
                station_eq[s][b] = default_eq[b];
        }
    }

    private string get_eq_path(int idx) {
        return Path.build_filename(eq_dir, "station_%d.conf".printf(idx));
    }

    private void save_station_eq(int idx) {
        if (idx < 0 || idx >= station_urls.length) return;
        string path = get_eq_path(idx);
        var sb = new StringBuilder();
        for (int i = 0; i < EQ_BANDS; i++) {
            if (i > 0) sb.append(",");
            sb.append("%.1f".printf(station_eq[idx][i]));
        }
        sb.append("\n");
        try {
            FileUtils.set_contents(path, sb.str);
        } catch (Error e) {}
    }

    private void setup_player() {
        playbin = Gst.ElementFactory.make("playbin", "player");
        if (playbin == null) {
            status_label.label = "GStreamer error";
            return;
        }
        preamp = Gst.ElementFactory.make("volume", "preamp");
        equalizer = Gst.ElementFactory.make("equalizer-10bands", "eq");
        if (preamp != null && equalizer != null) {
            audio_bin = new Gst.Bin("audio_bin");
            audio_bin.add_many(preamp, equalizer);
            preamp.link(equalizer);
            var ghost_sink = new Gst.GhostPad("sink", preamp.get_static_pad("sink"));
            var ghost_src = new Gst.GhostPad("src", equalizer.get_static_pad("src"));
            audio_bin.add_pad(ghost_sink);
            audio_bin.add_pad(ghost_src);
            playbin.set("audio-filter", audio_bin);
        }
        var bus = playbin.get_bus();
        bus.add_signal_watch();
        bus.message.connect(on_bus_message);
        playbin.set("uri", station_urls[0]);
        playbin.set("volume", volume_scale.get_value());
        apply_preamp();
    }

    private void apply_preamp() {
        if (preamp == null) return;
        double db = preamp_scale.get_value();
        double linear = Math.pow(10.0, db / 20.0);
        preamp.set("volume", linear);
    }

    private void apply_eq_to_gstreamer() {
        if (equalizer == null) return;
        for (int i = 0; i < EQ_BANDS; i++) {
            double g = eq_enabled ? station_eq[current_station][i] : 0.0;
            equalizer.set("band%d".printf(i), g);
        }
        update_eq_led();
    }

    private void update_eq_value_labels() {
        for (int i = 0; i < EQ_BANDS; i++) {
            if (eq_value_labels[i] != null && eq_scales[i] != null) {
                double v = eq_scales[i].get_value();
                eq_value_labels[i].label = "%+.0f".printf(v);
            }
        }
    }

    private void update_eq_led() {
        eq_led.get_style_context().remove_class("led-red-on");
        eq_led.get_style_context().remove_class("led-red-off");
        eq_led.get_style_context().add_class(eq_enabled ? "led-red-on" : "led-red-off");
    }

    private void update_play_led(bool playing) {
        status_dot.get_style_context().remove_class("led-green-on");
        status_dot.get_style_context().remove_class("led-green-off");
        status_dot.get_style_context().add_class(playing ? "led-green-on" : "led-green-off");
        status_dot.visible = true;
    }

    private void apply_station_eq_to_ui(int idx) {
        if (idx < 0 || idx >= station_urls.length) return;
        for (int i = 0; i < EQ_BANDS; i++) {
            if (eq_scales[i] != null && eq_handler_ids[i] != 0)
                SignalHandler.block(eq_scales[i], eq_handler_ids[i]);
        }
        for (int i = 0; i < EQ_BANDS; i++) {
            if (eq_scales[i] != null)
                eq_scales[i].set_value(station_eq[idx][i]);
        }
        for (int i = 0; i < EQ_BANDS; i++) {
            if (eq_scales[i] != null && eq_handler_ids[i] != 0)
                SignalHandler.unblock(eq_scales[i], eq_handler_ids[i]);
        }
        update_eq_value_labels();
        apply_eq_to_gstreamer();
    }

    private void on_eq_changed() {
        if (current_station < 0 || current_station >= station_urls.length) return;
        for (int i = 0; i < EQ_BANDS; i++) {
            if (eq_scales[i] != null)
                station_eq[current_station][i] = eq_scales[i].get_value();
        }
        update_eq_value_labels();
        apply_eq_to_gstreamer();
    }

    private void on_eq_toggle() {
        eq_enabled = !eq_enabled;
        eq_toggle_btn.label = eq_enabled ? "EQ ON" : "EQ OFF";
        apply_eq_to_gstreamer();
    }

    private void on_eq_reset() {
        if (current_station < 0) return;
        for (int i = 0; i < EQ_BANDS; i++)
            station_eq[current_station][i] = default_eq[i];
        preamp_scale.set_value(-2.0);
        apply_station_eq_to_ui(current_station);
        save_station_eq(current_station);
    }

    private void on_eq_save() {
        if (current_station < 0) return;
        for (int i = 0; i < EQ_BANDS; i++) {
            if (eq_scales[i] != null)
                station_eq[current_station][i] = eq_scales[i].get_value();
        }
        save_station_eq(current_station);
        save_btn.label = "Saved!";
        Timeout.add(800, () => {
            save_btn.label = "SAVE";
            return false;
        });
    }

    private void on_preamp_changed() {
        apply_preamp();
    }

    private void on_station_changed() {
        int new_idx = station_combo.active;
        if (new_idx < 0 || new_idx == current_station) return;
        current_station = new_idx;
        apply_station_eq_to_ui(current_station);
        if (is_playing) {
            playbin.set_state(Gst.State.NULL);
            playbin.set("uri", station_urls[current_station]);
            playbin.set_state(Gst.State.PLAYING);
            status_label.label = "Playing...";
            update_play_led(true);
            pause_button.label = "⏸  Pause";
        }
    }

    private void on_pause_clicked() {
        if (playbin == null) return;
        if (!is_playing) {
            playbin.set("uri", station_urls[current_station]);
            playbin.set_state(Gst.State.PLAYING);
            is_playing = true;
            pause_button.label = "⏸  Pause";
            status_label.label = "Playing...";
            update_play_led(true);
        } else {
            Gst.State state;
            playbin.get_state(out state, null, 0);
            if (state == Gst.State.PLAYING) {
                playbin.set_state(Gst.State.PAUSED);
                pause_button.label = "▶  Play";
                status_label.label = "Paused";
                update_play_led(false);
            } else {
                playbin.set_state(Gst.State.PLAYING);
                pause_button.label = "⏸  Pause";
                status_label.label = "Playing...";
                update_play_led(true);
            }
        }
    }

    private void on_stop_clicked() {
        if (playbin == null) return;
        playbin.set_state(Gst.State.NULL);
        is_playing = false;
        pause_button.label = "▶  Play";
        status_label.label = "Stopped";
        update_play_led(false);
    }

    private void on_volume_changed() {
        if (playbin != null)
            playbin.set("volume", volume_scale.get_value());
    }

    private void on_bus_message(Gst.Bus bus, Gst.Message msg) {
        switch (msg.type) {
            case Gst.MessageType.ERROR:
                Error err;
                string debug;
                msg.parse_error(out err, out debug);
                status_label.label = "Error";
                update_play_led(false);
                is_playing = false;
                pause_button.label = "▶  Play";
                break;
            case Gst.MessageType.EOS:
                status_label.label = "Ended";
                update_play_led(false);
                is_playing = false;
                pause_button.label = "▶  Play";
                break;
            case Gst.MessageType.STATE_CHANGED:
                if (msg.src == playbin) {
                    Gst.State old_state, new_state, pending;
                    msg.parse_state_changed(out old_state, out new_state, out pending);
                    if (new_state == Gst.State.PLAYING) {
                        status_label.label = "Playing...";
                        update_play_led(true);
                        is_playing = true;
                        pause_button.label = "⏸  Pause";
                    }
                }
                break;
        }
    }

    private void refresh_station_combo() {
        station_combo.remove_all();
        foreach (var name in station_names)
            station_combo.append_text(name);
        if (station_names.length > 0)
            station_combo.active = 0;
    }

    private void load_custom_stations() {
        try {
            if (!FileUtils.test(config_file, FileTest.EXISTS)) return;
            string content;
            FileUtils.get_contents(config_file, out content);
            foreach (var line in content.split("\n")) {
                var parts = line.split("|", 2);
                if (parts.length == 2 && parts[0].strip() != "" && parts[1].strip() != "") {
                    station_names += parts[0].strip();
                    station_urls += parts[1].strip();
                }
            }
        } catch (Error e) {}
    }

    private void save_custom_stations() {
        try {
            var dir = Path.get_dirname(config_file);
            DirUtils.create_with_parents(dir, 0755);
            var sb = new StringBuilder();
            for (int i = 16; i < station_names.length; i++) {  // променено от 10 на 16
                sb.append(station_names[i]);
                sb.append("|");
                sb.append(station_urls[i]);
                sb.append("\n");
            }
            FileUtils.set_contents(config_file, sb.str);
        } catch (Error e) {}
    }

    private void on_remove_station() {
        int idx = station_combo.active;
        if (idx < 16 || idx >= station_names.length) return;  // променено от 10 на 16
        if (is_playing && current_station == idx) {
            playbin.set_state(Gst.State.NULL);
            is_playing = false;
            pause_button.label = "▶  Play";
            status_label.label = "Stopped";
            update_play_led(false);
        }
        var new_names = new string[station_names.length - 1];
        var new_urls = new string[station_urls.length - 1];
        int j = 0;
        for (int i = 0; i < station_names.length; i++) {
            if (i == idx) continue;
            new_names[j] = station_names[i];
            new_urls[j] = station_urls[i];
            j++;
        }
        station_names = new_names;
        station_urls = new_urls;
        init_eq_memory();
        refresh_station_combo();
        if (station_names.length > 0)
            station_combo.active = int.min(idx, station_names.length - 1);
        save_custom_stations();
    }

    private void on_add_station() {
        var dialog = new Gtk.Dialog.with_buttons(
            "Add Station", window, Gtk.DialogFlags.MODAL,
            "Cancel", Gtk.ResponseType.CANCEL,
            "Add", Gtk.ResponseType.OK, null
        );
        dialog.set_default_size(360, 140);
        var content = dialog.get_content_area() as Gtk.Box;
        content.spacing = 8;
        content.margin = 12;
        var name_entry = new Gtk.Entry() { placeholder_text = "Station name" };
        var url_entry = new Gtk.Entry() { placeholder_text = "Stream URL (http/https)" };
        content.pack_start(new Gtk.Label("Name:"), false, false, 0);
        content.pack_start(name_entry, false, false, 0);
        content.pack_start(new Gtk.Label("URL:"), false, false, 0);
        content.pack_start(url_entry, false, false, 0);
        dialog.show_all();
        if (dialog.run() == Gtk.ResponseType.OK) {
            var name = name_entry.text.strip();
            var url = url_entry.text.strip();
            if (name != "" && url != "" && (url.has_prefix("http://") || url.has_prefix("https://"))) {
                station_names += name;
                station_urls += url;
                init_eq_memory();
                station_combo.append_text(name);
                station_combo.active = station_names.length - 1;
                save_custom_stations();
            }
        }
        dialog.destroy();
    }

    public override int command_line(ApplicationCommandLine command_line) {
        activate();
        return 0;
    }

    public static int main(string[] args) {
        var app = new RadioPlayer();
        return app.run(args);
    }
}
